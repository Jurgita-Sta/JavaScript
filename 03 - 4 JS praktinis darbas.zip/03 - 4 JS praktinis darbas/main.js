let addForm = document.querySelector("form");
let list = document.querySelector('#list');
addForm.addEventListener('submit', function (e) {
    e.preventDefault();
    let value = addForm.querySelector("input").value;
    let newListItem = document.createElement('li');
    newListItem.textContent = value;
    list.appendChild(newListItem);
    addForm.reset();
     
});
