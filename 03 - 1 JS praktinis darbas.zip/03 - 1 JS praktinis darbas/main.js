let randomNumber = parseInt((Math.random() * 100) + 1);
let userInput = document.querySelector('#guessField');
let msg = document.querySelector('#msg');
let numGuesses = 1;
let playGame = true;

if (playGame) {
    subt.addEventListener('click', function (e) {
        e.preventDefault();
        let guess = parseInt(userInput.value);
        checkGuess(guess);
    });
}

function checkGuess(guess) {
    if (guess === randomNumber) {
        numGuesses++;
        msg.textContent = `You guessed correctly in ${numGuesses} guesses`;
        playGame = false;
    } else if (guess < randomNumber) {
        numGuesses++;
        msg.textContent =`Number is too low!`;
    } else if (guess > randomNumber) {
        numGuesses++;
       msg.textContent = `Number is too high!`;
    }
}

