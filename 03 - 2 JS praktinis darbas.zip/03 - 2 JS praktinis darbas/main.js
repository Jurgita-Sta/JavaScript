let calculatorForm = document.querySelector("form");
let result = document.querySelector("#result");

calculatorForm.addEventListener("submit", function (e) {
    e.preventDefault();
    let num1 = +(calculatorForm["num1"].value);
    let num2 = Number(calculatorForm["num2"].value);
    result.textContent = "Result: " + (num1 + num2);
});
