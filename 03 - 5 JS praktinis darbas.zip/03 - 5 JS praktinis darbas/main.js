let firstInputField = document.querySelector("#firstInput");

firstInputField.addEventListener("focus", function(event) {
    event.preventDefault();
    event.target.style.background = "pink";    
});

firstInputField.addEventListener('blur', function(event) {
  event.target.style.background = "";    
});

let secondInputField = document.querySelector("#secondInput");

secondInputField.addEventListener("focus", function(event) {
  event.target.style.background = "blue";    
});

secondInputField.addEventListener("blur", function (event) {
  event.target.style.background = "";    
});