const changePic = document.querySelector("form");
const result = document.querySelector("#result");

changePic.addEventListener("submit", function (e) {
    e.preventDefault();
    let op = changePic["operator"];
    let selected = op[op.selectedIndex].value;
    switch (selected) {
        case "spring":
            result.setAttribute("src", "IMG/spring.jpg");
            break;
        case "summer":
            result.setAttribute("src", "IMG/summer.jpg");
            break;
        case "autumn":
            result.setAttribute("src", "IMG/autumn.jpg");
            break;
        case "winter":
            result.setAttribute("src", "IMG/winter.jpg");
            break;

    }
})
