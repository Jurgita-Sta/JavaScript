let calculatorForm = document.querySelector("form");
let result = document.querySelector("#result");
let description = document.querySelector("#description");

calculatorForm.addEventListener("submit", function (e) {
    e.preventDefault();
    let weight = +(calculatorForm["weight"].value);
    let height = Number(calculatorForm["height"].value);
    validateValues(weight, height);

})

function validateValues(weight, height) {
    if (isNaN(weight) || isNaN(height)) {
        alert('Please enter a valid number');
    } else if (weight < 5) {
        alert('Invalid weight value, have to be more than 5')
    } else if (height < 0 || height > 2.3) {
        alert('Invalid height value, have to be more than 0 and less than 2.3')
    } else {
        result.textContent = weight / Math.pow(height, 2);
        addDescription(weight / Math.pow(height, 2));
    }
}

function addDescription(result) {
    if (result < 18.5) {
        description.textContent = "Your weight is too low.";
    } else if (result >= 18.5 && result < 25) {
        description.textContent = "Your weight is normal.";
    } else if (result >= 25 && result < 30) {
        description.textContent = "Owerweight!";
    } else {
        description.textContent = "Obesity!";
    }
}
